Installation
---------------

### Setup

```sh
$ composer install
$ npm install
```